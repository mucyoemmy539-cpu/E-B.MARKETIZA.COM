const COMMISSION_RATE = 0.10;
const CURRENCY = "USD"; // Change to SEK, RWF, EUR, etc. for your deployment.

const products = [
 {id:1,name:"Wireless Headphones",category:"Electronics",price:59.99,icon:"🎧",seller:"E&B Tech"},
 {id:2,name:"Smart Watch",category:"Electronics",price:89.99,icon:"⌚",seller:"E&B Tech"},
 {id:3,name:"Classic Hoodie",category:"Fashion",price:39.99,icon:"🧥",seller:"Urban Store"},
 {id:4,name:"Everyday Sneakers",category:"Fashion",price:64.99,icon:"👟",seller:"Urban Store"},
 {id:5,name:"Modern Lamp",category:"Home",price:34.99,icon:"💡",seller:"Home Plus"},
 {id:6,name:"Coffee Maker",category:"Home",price:79.99,icon:"☕",seller:"Home Plus"},
 {id:7,name:"Beauty Care Set",category:"Beauty",price:44.99,icon:"✨",seller:"Beauty Hub"},
 {id:8,name:"Skincare Essentials",category:"Beauty",price:29.99,icon:"🧴",seller:"Beauty Hub"}
];

let cart = JSON.parse(localStorage.getItem("eb_cart") || "[]");
let activeCategory = "All";
let selectedPayment = null;

function money(v){return `${CURRENCY} ${Number(v).toFixed(2)}`}

function renderProducts(){
 const q=(document.getElementById("searchInput")?.value||"").toLowerCase();
 const list=products.filter(p=>(activeCategory==="All"||p.category===activeCategory)&&
   (p.name.toLowerCase().includes(q)||p.seller.toLowerCase().includes(q)));
 document.getElementById("resultCount").textContent=`${list.length} products`;
 document.getElementById("productGrid").innerHTML=list.map(p=>`
  <article class="product">
   <div class="pic">${p.icon}</div>
   <div class="info">
    <div class="muted">${p.category} · ${p.seller}</div>
    <h3>${p.name}</h3>
    <div class="price">${money(p.price)}</div>
    <button onclick="addToCart(${p.id})">Add to cart</button>
   </div>
  </article>`).join("");
 document.getElementById("cartCount").textContent=cart.reduce((a,i)=>a+i.qty,0);
}

function setCategory(c){activeCategory=c;renderProducts()}
function addToCart(id){
 const item=cart.find(x=>x.id===id);
 if(item)item.qty++; else cart.push({id,qty:1});
 localStorage.setItem("eb_cart",JSON.stringify(cart));renderProducts();
}
function removeItem(id){cart=cart.filter(x=>x.id!==id);localStorage.setItem("eb_cart",JSON.stringify(cart));showCart();renderProducts()}
function closeModal(){document.getElementById("modal").classList.remove("show")}

function showCart(){
 const rows=cart.map(i=>{const p=products.find(x=>x.id===i.id);return {...p,qty:i.qty,line:p.price*i.qty}});
 const subtotal=rows.reduce((a,i)=>a+i.line,0);
 document.getElementById("modalContent").innerHTML=`
  <h2>Your Cart</h2>
  ${rows.length?rows.map(i=>`<div class="row"><span>${i.icon} ${i.name} × ${i.qty}</span><span>${money(i.line)} <button onclick="removeItem(${i.id})">Remove</button></span></div>`).join(""):`<p>Your cart is empty.</p>`}
  <div class="row"><strong>Order subtotal</strong><strong>${money(subtotal)}</strong></div>
  <div class="commission"><strong>Marketplace commission:</strong> 10% is automatically calculated for seller orders. For a ${money(subtotal)} order, the platform commission is <strong>${money(subtotal*COMMISSION_RATE)}</strong> and the seller payout is <strong>${money(subtotal*(1-COMMISSION_RATE))}</strong>.</div>
  ${rows.length?`<h3>Choose payment method</h3>
   <div class="pay-grid">
    <button class="pay" onclick="selectPayment('Card')">💳 Card<br><span class="muted">Visa / Mastercard</span></button>
    <button class="pay" onclick="selectPayment('PayPal')">🅿️ PayPal<br><span class="muted">PayPal checkout</span></button>
    <button class="pay" onclick="selectPayment('Mobile Money')">📱 Mobile Money<br><span class="muted">MoMo / supported mobile wallets</span></button>
    <button class="pay" onclick="selectPayment('Bank')">🏦 Bank transfer<br><span class="muted">Local bank payment</span></button>
   </div>
   <div id="paymentInfo" class="notice">Select a payment method.</div>
   <button class="checkout" onclick="startCheckout(${subtotal})">Continue to secure checkout</button>`:""}
 `;
 document.getElementById("modal").classList.add("show");
}

function selectPayment(method){
 selectedPayment=method;
 const info=document.getElementById("paymentInfo");
 if(method==="Mobile Money"){
   info.innerHTML=`<strong>Mobile Money / MoMo selected.</strong><br>In production, this connects to a licensed payment provider and the buyer enters their own payment details in the provider's secure checkout.`;
 } else if(method==="Card"){
   info.innerHTML=`<strong>Card selected.</strong><br>Production checkout should use a PCI-compliant provider such as Stripe or another supported payment gateway.`;
 } else if(method==="PayPal"){
   info.innerHTML=`<strong>PayPal selected.</strong><br>Production checkout redirects to the official PayPal payment flow.`;
 } else {
   info.innerHTML=`<strong>Bank transfer selected.</strong><br>Production mode should create a payment reference and verify the transfer server-side.`;
 }
}
function startCheckout(subtotal){
 if(!selectedPayment){alert("Please select a payment method.");return}
 alert(`Demo checkout: ${selectedPayment}\\nAmount: ${money(subtotal)}\\nMarketplace commission: ${money(subtotal*COMMISSION_RATE)}\\nSeller payout: ${money(subtotal*0.90)}\\n\\nConnect a real payment provider/backend before accepting real payments.`);
}

function showSeller(){
 const demoSales=1250;
 const commission=demoSales*COMMISSION_RATE;
 const payout=demoSales-commission;
 document.getElementById("modalContent").innerHTML=`
  <h2>Seller Center</h2>
  <p class="muted">Every completed seller order automatically reserves 10% for E&B MARKETIZA.</p>
  <div class="row"><span>Demo gross sales</span><strong>${money(demoSales)}</strong></div>
  <div class="row"><span>Marketplace commission (10%)</span><strong>${money(commission)}</strong></div>
  <div class="row"><span>Seller net payout (90%)</span><strong>${money(payout)}</strong></div>
  <div class="notice"><strong>Payment methods:</strong> Card, PayPal, Mobile Money/MoMo, and Bank Transfer are supported in the interface. Real payments require server-side integration with licensed providers.</div>
  <h3>Important production setup</h3>
  <p>Commission must be calculated and enforced on the server, not only in JavaScript. Payment webhooks should verify successful payments before creating orders or releasing seller payouts.</p>`;
 document.getElementById("modal").classList.add("show");
}

document.getElementById("searchBtn").addEventListener("click",renderProducts);
document.getElementById("searchInput").addEventListener("input",renderProducts);
renderProducts();
