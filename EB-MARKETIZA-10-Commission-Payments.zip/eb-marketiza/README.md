# E&B MARKETIZA

A responsive multi-vendor e-commerce marketplace starter for E&B.MARKETIZA.COM.

## Included
- Product catalog, search and categories
- Shopping cart with localStorage
- Seller Center demo
- Automatic 10% marketplace commission calculation
- Seller payout calculation (90%)
- Checkout UI with Card, PayPal, Mobile Money/MoMo and Bank Transfer
- Responsive design

## Important: real payments
This repository is a front-end/demo implementation. It does NOT process real money.

For production, use a secure backend and a marketplace-capable payment provider. The backend should:
1. Create the payment/order server-side.
2. Calculate the 10% platform commission server-side.
3. Verify payment using provider webhooks.
4. Store orders and seller payouts in a database.
5. Never collect or store raw card credentials.
6. Use the provider's supported Mobile Money/MoMo integration for the countries where E&B MARKETIZA operates.
7. Handle refunds, disputes, taxes, currency conversion and seller verification according to local law/provider rules.

Suggested production stack: Next.js/TypeScript + PostgreSQL + a marketplace payment provider such as Stripe Connect where available, plus a licensed Mobile Money aggregator/provider for the target countries.

## Run
Open `index.html` in a browser for the demo.

## GitHub
Create a repository named `EB-MARKETIZA`, upload these files, and enable GitHub Pages if you want to host this static demo.
